// plugins/bootstrap.client.ts
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

export default defineNuxtPlugin(() => {
  console.log('Bootstrap JS has been loaded.');
});
