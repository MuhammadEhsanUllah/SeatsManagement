<script lang="ts" setup></script>
<template>
    <div>
        <div class="row w-100">
            <div class="col-2">
                <Sidebar />
            </div>
            <div class="col-10">
               <AddSeats />
            </div>
        </div>
    </div>
</template>